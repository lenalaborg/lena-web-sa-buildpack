#!/bin/bash
if [ ! -d /home/ec2-user/.ssh ] ; then
    mkdir -p /home/ec2-user/.ssh
    chmod 700 /home/ec2-user/.ssh
fi

# Fetch public key using HTTP 
curl http://169.254.169.254/latest/meta-data/public-keys/0/openssh-key > /tmp/my-key

if [ $? -eq 0 ] ; then
    if [ ! -f /home/ec2-user/.ssh/authorized_keys ] ; then
        cat /tmp/my-key >> /home/ec2-user/.ssh/authorized_keys
        chown ec2-user:ec2-user /home/ec2-user/.ssh/authorized_keys
        chmod 700 /home/ec2-user/.ssh/authorized_keys
    fi
fi

rm /tmp/my-key

echo [LENA] set ssh key for user.

