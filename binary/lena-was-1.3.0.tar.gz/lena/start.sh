#!/bin/sh

SCRIPTPATH=`cd $(dirname $0) ; pwd -P`
SCRIPT=$SCRIPTPATH/$(basename $0)

. ${SCRIPTPATH}/env.sh

SETUSER=${WAS_USER}
RUNNER=`whoami`

if [ ${RUNNER} = "root" ] ;
   then >&2 echo "Deny Access : [ ${RUNNER} ]." ;
   exit 0 ;
fi

if [ ${RUNNER} != ${SETUSER} ] ;
   then >&2 echo "Deny Access : [ ${RUNNER} ]. Not ${SETUSER}" ;
   exit 0 ;
fi

if [ "`uname -s`" = "HP-UX" ]; then
	ps -efx | grep java | grep -q "was_cname=${INST_NAME} " && echo "##### ERROR. ${INST_NAME} is already running. exiting.. #####" && exit 1
else
	ps -ef | grep java | grep -q "was_cname=${INST_NAME} " && echo "##### ERROR. ${INST_NAME} is already running. exiting.. #####" && exit 1
fi

# DATE=`date +%Y-%m-%d_%H-%M-%S`
LOG_DATE=`date +%Y%m%d`

_log_dirs="access gclog hdump hdump/oom nohup sdump tdump"
for _dir in `echo $_log_dirs`
do
  if [ ! -d ${LOG_HOME}/${_dir} ]; then
    mkdir -p ${LOG_HOME}/${_dir}
    if [ $? -ne 0 ]; then
  	echo >&2 "cannot create log directory '${LOG_HOME}/${_dir}'";
  	echo >&2 "Startup failed."
  	exit 1;
    fi
  fi
done

if [ 0 -ne `ls ${LOG_HOME} | grep "gc_${INST_NAME}.*" | grep "\.log" | wc -l` ]; then
  mv ${LOG_HOME}/gc_${INST_NAME}*.log ${LOG_HOME}/gclog
fi

if [ 0 -eq `ls ${LOG_HOME} | grep "\.out.*" | grep -v "${LOG_DATE}" | wc -l` ]; then
  echo "Previous log does not exist"
else
  cd ${LOG_HOME}
  for LOG_FILE in `ls *.out* | grep -v "${LOG_DATE}"`
  do
    mv ${LOG_FILE} nohup/${LOG_FILE}.${DATE}
  done
fi

if [ 0 -eq `ls ${LOG_HOME} | grep "access_${INST_NAME}.*" | grep -v "${LOG_DATE}" | wc -l` ]; then
  echo "Previous access log does not exist"
else
  cd ${LOG_HOME}
  for LOG_FILE in `ls access_${INST_NAME}.* | grep -v "${LOG_DATE}"`
  do
    mv ${LOG_FILE} access/${LOG_FILE}.${DATE}
  done
fi

cd ${CATALINA_HOME}
${CATALINA_HOME}/bin/startup.sh
